﻿using System;
using PdfSharp.Drawing;
using PdfSharp.Pdf;
using PdfSharp.Pdf.IO;

namespace AddPicturetoPDF
{
           public class PicturetoPDF
        {
            public void GetPDFWithImage(
              string filename,
              string imgPath,
              int pageCount,
              int x,
              int y,
              int width,
              int height,
              string OutputPath)
            {
                PdfDocument pdfDocument = PdfReader.Open(filename, PdfDocumentOpenMode.Modify);

                int i = 0;
                while (i < pageCount)
                {
                    this.DrawImage(XGraphics.FromPdfPage(pdfDocument.Pages[i]), imgPath, x, y, width, height);
                    i++; 
                }

            pdfDocument.Save(OutputPath);
            }
        
            
        private void DrawImage(
              XGraphics imgGraphic,
              string bmpPath,
              int x,
              int y,
              int width,
              int height)
            {
                XImage image = XImage.FromFile(bmpPath);
                imgGraphic.DrawImage(image, (double)x, (double)y, (double)width, (double)height);
            }
        }
    }

