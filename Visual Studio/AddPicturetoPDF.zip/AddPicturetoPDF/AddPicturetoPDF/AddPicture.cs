﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Activities;
using System.ComponentModel;
using System.Drawing;

namespace AddPicturetoPDF
{
    public class AddPicture : CodeActivity
    {

        [Category("Input")]
        [Description("The full path of the input PDF file")]
        [RequiredArgument]
        public InArgument<string> PdfPath { get; set; }

        [Category("Input")]
        [Description("The full path of the picture to be added in a PDF document")]
        [RequiredArgument]
        public InArgument<string> PicturePath { get; set; }

        [Category("Image")]
        [Description("Enter integer value for horizontal position of the image. (Default value: 0px)")]
        public InArgument<int> OffsetX { get; set; }

        [Category("Image")]
        [Description("Enter integer value for vertical position of the image. (Default value: 0px)")]
        public InArgument<int> OffsetY{ get; set; }

        [Category("Image")]
        [Description("Enter width for the image (pixels).")]
        public InArgument<int> Width { get; set; }

        [Category("Image")]
        [Description("Enter height for the image (pixels).")]
        public InArgument<int> Height { get; set; }

        [Category("Output")]
        [Description("The full path of the output PDF file. It should include filename along with the extension.")]
        [RequiredArgument]
        public InArgument<string> OutputPath { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            string filename = this.PdfPath.Get((ActivityContext)context);
            string str = this.PicturePath.Get((ActivityContext)context);
            string OutputPath = this.OutputPath.Get((ActivityContext)context);
           
            int pageCount;
            int x = this.OffsetX.Expression != null ? this.OffsetX.Get((ActivityContext)context) : 0;
            int y = this.OffsetY.Expression != null ? this.OffsetY.Get((ActivityContext)context) : 0;
            Image image = Image.FromFile(str);
            int width = this.Width.Expression != null ? this.Width.Get((ActivityContext)context) : image.Width;
            int height = this.Height.Expression != null ? this.Height.Get((ActivityContext)context) : image.Height;
            pageCount = PdfSharp.Pdf.IO.PdfReader.Open(filename, PdfSharp.Pdf.IO.PdfDocumentOpenMode.InformationOnly).PageCount;
            new PicturetoPDF().GetPDFWithImage(filename, str, pageCount, x, y, width, height, OutputPath);
        }
    }
}
